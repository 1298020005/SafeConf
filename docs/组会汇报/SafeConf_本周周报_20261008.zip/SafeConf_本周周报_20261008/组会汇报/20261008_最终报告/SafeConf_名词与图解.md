# SafeConf：名词、公式、特征与图的完整解释

这份文档对应本目录主报告和单独导出的图。按数据、方法、符号、算法、特征、统计和来源组织。解释采用本项目的实际含义，不用类比。

阅读顺序：先看数据和三个信息来源，再看公式与特征，最后看统计和发表名词。每个英文图标签的完整中文含义在文末另列。

## 1. 先理解数据和要预测的对象

### 单细胞 / single-cell / cell

每个细胞分别测量。本项目的原始表达矩阵通常一行一个细胞、一列一个基因；评价任务的效应向量往往再由一组细胞平均得到。细胞数量不等于独立扰动实验数量。

### 基因、表达 / gene, genes, gene expression, RNA

基因表达是RNA测量的数值。不同基因对应输出向量中的不同位置。扰动目标基因和测量输出的基因是两个集合，目标基因不必位于某个选定输出面板中。

### 扰动 / perturbation, perturbations, intervention

实验主动改变的因素。本项目涉及遗传扰动、药物和细胞因子刺激；当前文章主结果集中在遗传扰动。相同基因但不同扰动方式、剂量或时间，不自动属于相同实验条件。

### 遗传扰动 / genetic, CRISPR, CRISPRi, knockout, KO, knockdown

CRISPR相关实验用于改变特定基因。敲除、转录抑制和降低表达是不同操作，历史资格需要记录实际操作。不能因目标基因名称相同就合并不同干预。

### 药物、细胞因子 / chemical, drug, cytokine, stimulus

药物与细胞因子是不同类型的处理。早期材料有类型字段修正，正式分析按实验含义归类；当前遗传扰动结果不直接推出药物或细胞因子的效果。

### 背景、条件 / context, condition, state, dose, time

背景可以包括细胞系、供体、状态或培养条件；条件还包含具体处理、剂量和时间。一个任务由扰动和这些字段共同确定。Native61中的状态列是实际背景输入，不是预测器名称。

### 对照 / control, controls, baseline expression

未接受对应目标扰动或符合指定对照定义的细胞。效应通过处理组与对照表达的差得到。对照选法、批次和是否共享，都会影响效应与误差。baseline expression在Native61中指目标基因在对照细胞中的表达。

### 效应 / effect, response, outcome, delta

处理后的变化向量。本项目常用归一化表达中处理均值减对照均值。它有正值和负值，分别表示相对对照增加与降低。当前未知outcome指还没获得当前任务的真实处理结果。

### 真值 / truth, ground truth, observed

这里通常是实验细胞构造的观察效应，不是无噪声的生物常数。评价时拿它与预测比较；公共库使用的真值来自允许的历史实验。当前查询答案不能成为其自身推理输入。

### 原始计数、归一化 / raw counts, normalization, log1p

原始计数是测得的RNA计数。归一化调整测序量等规模差异；log1p是log(1+x)。预测、历史和评价必须采用一致定义。先删基因再用剩余计数作归一化分母，会改变数值对象。

### 表达矩阵、效应向量 / matrix, vector, profile

矩阵包含多行细胞或实验、多列基因；效应向量是一次任务在一条固定基因轴上的变化。方法图的色条和曲线表示这种数据结构，是示意绘制，不是实际测得曲线。

### 基因轴、面板 / gene axis, panel, gene ordering

向量每个位置对应哪个基因以及其顺序。3352、2840、3285、512等是不同合同的维度，不是互换的常数。共同基因轴只包含确认对齐的基因；缺失基因不能直接填零。

### 掩码 / mask, missing genes, NaN, Inf, finite

掩码指定哪些位置可比较。NaN表示缺失或无法计算，Inf表示无穷值，finite表示有限值。它们和生物效应为零不同。有效值不足时记录状态，不生成假的历史。

### 任务 / task, query, task ID

某一扰动在特定背景及条件下的一次待评价预测。task ID是识别键，也是固定并列排序规则。相同任务多个模型或多个种子的预测不是多个独立生物实验。

### 扰动簇 / gene cluster, perturbation cluster, cluster

把同一个扰动基因或登记扰动身份的相关记录归在一起。拆折和bootstrap按簇操作，减少同基因多背景、多个预测器之间相关性导致的虚假样本量。

### 实验、重复 / experiment, experiment ID, replicate

experiment ID标识实际实验单位。独立guide、plate、供体或实验重复的含义要按设计判断；同一实验的多个文件包装不能算多个重复。

### guide、plate、batch、donor

guide是实验中指向扰动目标的引导序列；plate是实验板；batch是批次；donor是生物供体。它们可能用于质量与重复诊断，但不能一律视为相互独立的生物实验。

### 支持量 / support, count, n_cells, history support

支持量描述历史有多少细胞、实验或背景等资料。当前支持权重常依据合格记录的细胞数；独立单位仍按实验和扰动簇记录。细胞多可以提高平均值精度，但不自动证明实验没有偏差。

### 实验质量 / quality, reliability, reproducibility

质量依据重复实验一致性、批次一致性、分半稳定性等测量。它与支持量不同；缺少重复资料时，质量应记为缺失，而不是由细胞数量代替。

### 相关性与冲突 / relevance, conflict, history conflict

相关性指历史与查询的扰动、背景、条件是否适合；冲突指合格历史的响应是否互相不一致。历史原始冲突与变换后分散度分开保存，投影把差异缩小不等于实验更可靠。

### 公共历史资格 / eligible, eligibility, matched histories, historical

资格是一组数据使用条件：来源可追溯、实验含义和输出轴兼容、排除当前实验和禁止重复。matched histories表示已经按这些字段匹配的历史，不表示它们必定正确反映新背景。

### 输出合同 / output contract, effect contract

约定预测和实验向量的具体含义：效应方向、对照、归一化、基因顺序和掩码等。合同是数据与计算规则；不同原始误差不能在未经处理时混为共同监督标签。

### 来源追踪 / provenance, lineage, snapshot

来源追踪说明记录来自哪里、由什么处理得到。lineage是派生关系，snapshot是一次冻结版本。它们用于排除重复、查修复影响范围和恢复旧结果。

### 观测误差与生物误差 / measurement noise, technical stability, biological

观测误差包含实验估计的不稳定；生物误差指预测与真实生物效应的偏离。有限细胞、共享对照等可能影响观测误差排名。独立重复与技术分半诊断用于区分这些因素。

## 2. 方法、三个信息来源和图的阅读

### SafeConf、SafeTrans、PolicySafeTransPT

SafeConf是当前项目名称。SafeTrans及PolicySafeTransPT是早期项目与完整迁移系统的名称，包含检索、路由等原型。主报告保留其演变，不把旧原型当成当前全部采用的模型。

### 预测器 / predictor, prediction, predictions, model

预测器输出扰动效应。SafeConf的风险学习器输出风险分数，两者的训练目标不同。图中C是被审核的冻结预测器；A/B代表提供合法错误经验的其他预测器。

### 冻结预测器 / frozen predictor, frozen

固定参数、数据划分和输出版本后生成预测。冻结后根据评价成绩换参数会改变实验角色。使用已有checkpoint导出预测，与重新训练预测器是不同成本。

### 风险分数、排序 / risk, score, scoring, rank, ranking

风险分数越高越优先复核。排序是按分数和固定并列键确定次序。它不是当前预测的误差概率，也不必以RMSE单位表示。归一到[0,1]只改变尺度，不自动完成概率校准。

### 可信度 / confidence

可信度通常越高越可信；风险越高越需复核，方向相反。文档以风险方向为主。旧文件叫confidence时，要检查其实际方向，不能按名称猜测。

### 任务风险、单模型风险、家族风险 / task risk, predictor risk, family risk

任务风险强调多个预测器共同困难；单模型风险绑定一个冻结预测器；家族风险绑定事前注册的一组预测。旧分歧结果和当前误差学习要明确属于哪个对象，相关性不自动区分共同难度与模型特异错误。

### Public、Public Memory、public experiments

Public使用合法历史真实实验构造生物参照或训练生物迁移学习器。它不以A/B预测错误作为生物学习答案。Public Memory保存实验效应、背景、对照、支持、质量和来源。

### 公共参照 / reference, prior, public historical reference

参照是从合格历史计算的效应向量，供当前预测比较。代码中的prior多指这份参照，不自动表示贝叶斯先验。µ是其加权均值。

### PublicRule、加权历史距离 / weighted history distance

当前公共规则计算预测到所有合格历史的加权均方距离开方。它等于sqrt(D²+V)。单条历史V=0；该恒等式是标准范数性质，不是新理论贡献。

### Source、Shared、SourceRisk、共享风险学习器 / shared risk learner

Source是其他预测器的合法错误监督；Shared是由它学到的风险知识或分数。共享学习器输入当前预测与公共证据，输出风险。Source错误在训练时进入参数，不在每个查询时逐条检索错误答案。

### Target、TargetRisk、目标适配 / target, feedback, adaptation, adapt

Target是当前预测器自己已开放的错误反馈。目标适配器利用这些记录学习C的错误特点。Adaptation是按本项目数据和输出规则接入现有方法，区别于完整原作者研究复现。

### 可迁移、兼容 / transfer, transferable, compatible

迁移指用A的错误监督评价B或C。兼容至少要求字段含义、输出轴、效应规则和数据范围合格。相同方法可用于两种模型，不等于完成A→B错误迁移；必须实际交叉训练。

### 反馈 / limited feedback, target feedback, observed errors

反馈是冻结预测之后获得的真实结果与错误。预算按独立基因簇取样，同时记录实际任务行。CDF、融合和选型使用的错误也算预算；一个错误被多次使用只计一次生物记录。

### 当前默认、条件增量、候选、并行 / default, conditional gain, candidate, parallel

default表示当前选中配置；conditional gain表示在登记条件内使用；candidate表示经过比较才可能启用；parallel表示独立研究线。方法图中的Source/Target不是每个任务都必须加入。

### 无历史 / no history, unavailable, fallback

没有符合合同的历史时，返回冻结的幅度起点和明确状态。fallback是回退规则，不是造一个零效应参照。混合排序的通道尺度在训练侧固定。

### 融合与切换 / fusion, gate, reader, channel

融合器学习如何合用多项输入；gate决定何时使用某个评分分支；reader是解释预测与参照的风险学习器；channel是某类分数。统一接口可以调用不同规则，不要求全部经过同一融合器。

### Source gate的四个选项 / always_public, top25, top50, top75

分别为始终公共、在不可靠程度最高25%/50%/75%任务中切换到Source。阈值和两路分数尺度只用训练侧确定。包含不切换选项，避免无收益时仍被迫启用Source。

### 更新、发布与回滚 / update, release, retain, rollback

新记录入库后训练候选，训练侧检查通过才发布。retain表示保留旧参数；rollback是恢复完整旧版本。接收新数据并不等于每次更新都会改善表现。

### Public有效、覆盖扩展、背景映射

三个不同问题：历史本身能否提供有效判断；增加历史是否覆盖更多任务；转换历史响应是否额外改进判断。映射候选退出不会抹去旧公共结果。

### 复核 / review, prioritise, prioritize, top 20%

review表示按风险选出需进一步检查的预测。这里的数值收益是用已知实验答案进行离线评价，不表示已经完成新的湿实验。prioritise/prioritize是同一词的英式/美式拼写。top20%取ceil(0.2n)。

### 条件内与全量排序 / within, global, mixed cohort

条件内指标在每个背景内部计算；global在全队列选一次前20%；mixed cohort包含有历史与无历史任务。两种汇总可能不同，不能把它们的分数混为同一个指标。

### a、b、c、d / panel labels

图中的小写字母只是分面编号。大写A/B/C是预测器角色；D是距离；这些字母含义不同。方法图按新预测、参照审核和复核分面。

### 方法图的图形与颜色

细胞和培养皿表示实验；色条表示效应向量；曲线表示预测与参照；树形符号表示风险学习器。绿色实线为公共主干，蓝色与橙色虚线为可选学习，灰色独立线为家族证书。阴影表示历史变化的示意，不是校准置信区间。

## 3. 符号、公式和参数

### ŷ、y、h_i、µ、w_i、G、m

ŷ是预测效应，y是评价实验效应，h_i是第i条合格历史；µ=Σw_i h_i；w_i非负且总和为1；G是当前共同轴基因数；m是历史实验记录数。i为历史索引，q为查询索引。

### D、V、σ、R

D是预测与公共均值的RMSE距离；V是历史效应的加权平均平方偏差；σ=sqrt(V)。代码prior_uncertainty存σ，公式用V时不能再把它平方一次。R是风险分数；R_public=sqrt(D²+V)。

### 平方范数、均值 / norm, mean, squared

平方范数是向量各位置平方相加。除以G后是平均平方量。开方后回到原表达量尺度。均值mean、绝对值均值和均方根是不同计算。

### Δ、差值、增量 / difference, delta, increment

统计表的Δ一般为候选减对照的实际点估计。图中曲线旁的Δ只是局部效应差的示意；D在全共同基因轴计算。bootstrap平均差值与实际观测差值分列。

### 预测幅度 / magnitude, amplitude, M

M=sqrt(mean(ŷ²))，由预测向量计算。它描述预测变化的大小，不使用当前实验答案。以真实效应幅度作为预测时输入会改变信息条件。

### Q、秩、百分位 / rank, percentile

Q把分数变成相对名次尺度。它说明在参考分布中处于什么位置，不说明错误概率或绝对误差。SafeConf-M采用0.8Q(M)+0.2Q(S)，S是旧固定风险分。

### CDF、ECDF、中间秩 / cumulative distribution function, midrank

经验CDF由允许的训练数值构造。中间秩对相同数值给予相同标签。必须区分错误标签CDF和通道分数CDF；目标C没有风险标签时不能用其真误差拟合CDF。

### 错误标签CDF / error-label CDF

把某一兼容模型、背景与预算内训练误差转成排序监督。10%预算的CDF只使用这10%。不同原始RMSE不直接跨模型混合；分组键只处理标签和审计，不作为身份特征。

### 通道分数CDF / channel-score CDF

把幅度、公共距离、Shared等通道各自变换成训练参考分布的相对秩。它不读取真实错误就可以用于无监督规则的尺度处理，但相同百分位仍不保证相同风险含义。

### CDF分辨率、并列 / resolution, tie, jump

n个训练错误的名义粒度约1/n；并列会造成更大的跳跃。只有一个有效错误值时没有排序信息。标签覆盖和分辨率变化会影响小预算曲线，不能全归因于知识更多。

### Jackknife、J²、delete-one

逐条删除独立历史记录并重算加权均值，计算J²=(m−1)/m × Σ mean((µ_−i−µ)²)。这里用作参照对记录变化的敏感性。求和不能误写成平均；实验相关时它也不自动成为正确标准误。

### n_eff、有效历史数 / effective sources

常见权重数量指标为1/Σw_i²；所有权重相等时等于历史条数，集中于一条时接近1。它反映权重集中程度，不能证明历史相互独立。

### 均值不确定性、新实验波动 / uncertainty of mean, variation

均值不确定性讨论µ估得是否稳定；新实验波动讨论另一次实验会偏离µ多少。独立实验增加可能减少均值误差，却不必减少背景间真实差异。V与J因此分别定义。

### τ、温度、softmax权重 / temperature

曾登记的公共候选用exp(−(估计误差−最小估计误差)/τ)形成权重，τ由训练区折外残差估计。它控制权重集中程度，不是候选级置信区间；候选结果保留而未升级默认。

### λ、α、正则 / lambda, alpha, regularization

正则惩罚复杂参数。Ridge的α和映射公式中的λ有不同损失约定，不能只因为数值相同就视为相同强度。固定Ridge风险对照α=10；映射候选用登记的λ集合。

### 学习率、轮数 / learning_rate, max_iter, n_estimators

学习率控制每轮新增树的贡献。轮数是加多少轮树。HGB和XGBoost字段名称不同，不表示新增了相同数量的独立实验。

### 树深、叶节点 / max_depth, min_samples_leaf, min_child_weight

树深限制分裂层次。HGB最小叶节点限制每个终端区间至少包含多少训练行。37行、最小叶20不能分成两个合格叶，可能输出常数。XGBoost的min_child_weight不是相同的行数参数。

### 小样本HGB、H0、H1、n_fit

H0为原固定HGB；H1只把最小叶改为min(20,max(2,n_fit//10))。n_fit是当前实际拟合区有效行数。它在每个训练分区计算，不从评价规模确定。

### L2、l2_regularization

L2惩罚树叶数值或线性系数过大，帮助有限样本下避免过强拟合。Source HGB的登记值为10；它不是误差大小或历史质量。

### subsample、colsample_bytree、hist、n_jobs

XGBoost的subsample表示每树抽取训练行的比例，colsample_bytree为特征比例，hist是直方图分裂方法，n_jobs是CPU线程数。当前配方行列比例均0.8、最多4线程。

### 随机种子 / seed, random_state

种子固定随机过程以复现。三个种子结果平均与某个主种子的配对CI不是同一个统计量。重复种子不增加独立基因、供体或研究数量。

### 行等权、簇等权 / row-equal, cluster-equal, sample_weight

行等权每条训练记录同权；簇等权让每个基因的全部记录合计同权。当前cluster_weights采用1/该基因行数再统一缩放。TabPFN不支持同一sample_weight接口时，必须分别报告。

### error decomposition、a、b、eps

令a=ŷ−y、b=µ−y，则D²=e²+mean(b²)−2mean(a·b)。它解释参照准确度和共同偏差方向如何影响距离。|D−e|≤RMSE(µ,y)是范数关系；右侧包含未知真值，不能用于当前任务保证。

### D_F、E_F、family certificate、lower bound、upper bound

D_F是注册家族预测向量围绕家族均值的离散程度，E_F是家族RMS误差。平方范数分解给出D_F≤E_F。最大成员还可用预测直径的一半作下界。上界另需登记校准与相应假设，不由下界自动得到。

## 4. 模型和已试过的方法

### HGB、HistGradientBoostingRegressor、GBT、GBDT

直方图梯度提升回归树。先有一个预测，再依次增加树以降低训练损失，树按特征阈值分裂。本项目用于预测风险或公共生物迁移误差，职责由训练标签决定。HGB是公开算法，不是SafeConf专有算法。

### XGBoost、X0

公开梯度提升树实现。PertEMA官方工厂使用XGBRegressor；本项目固定其树参数。X0指登记配方。和HGB属于相关树学习类型，但实现、参数与小数据行为不同。

### Ridge、岭回归、linear regression

线性回归加L2惩罚，学习输入特征的系数。可作风险对照或融合候选。它需要训练答案；放进公共规则后会增加错误监督，不能继续叫原始无错误标签规则。

### PertEMA、post-hoc、error meta-assessment

PertEMA是扰动错误后置评估项目。post-hoc表示在已有预测之后另做审核。它用预测时可获得特征和自身OOF错误训练树，还提供校准和区间相关流程；本次是固定代码配方的输入/目标适配。

### P6、Native61、Native61_Public

P6是六项通用预测特征。Native61是本项目61项控制与预测时特征适配：10个基础/状态字段、50维表示、1项训练相似度。Native61_Public增加同一七项公共输入，合计68列。

### OOF、out-of-fold、折外

某条记录的分数来自没有用该条记录及其扰动簇错误训练过的模型。上层融合器的训练输入必须这样生成，不能用下层模型在自身训练记录上的拟合分数。

### isotonic、单调校准、calibration

单调回归用合法训练侧折外分数及标签学习映射。校准要说明映射到什么目标；错误CDF标签校准不自动成为当前模型失败概率。原始分数和校准分数分别保存。

### conformal、prediction interval、coverage guarantee

conformal用合法校准误差形成预测集合或区间，覆盖性质依赖相应数据假设和协议。排序好、分数位于[0,1]或做了isotonic都不等于完成这项保证。本轮不把适配版写成完整官方区间复现。

### 训练相似度、prototype、nearest neighbour

相似度在这里是控制表示空间中到最近训练基因原型的距离。训练原型含自己时距离为零；新查询没有自己，可能产生分布错配。本轮修复训练行用最近其他基因，查询仍只搜索训练原型。

### embedding、control-only embedding、PCA

embedding是数值表示；当前Native61的50维表示来自控制表达，不使用查询处理后的真实响应。PCA是线性降维方法，其均值和基底只能在允许数据上拟合。表示维度不等于输出基因数。

### dropout、plate variance proxy、one-hot

dropout在控制特征中描述未测出表达的比例；plate variance proxy是板间变化的代理量，不等于独立供体方差；one-hot用一列一个状态的0/1编码表示背景。

### DeepSets、pointwise、Set Transformer

DeepSets通过处理每条历史并汇总集合，学习集合相关表示；pointwise逐条处理后生成权重；Set Transformer用注意力处理集合。前两者实际比较过，未成为当前整体默认；本轮没有增加第三种新网络。

### Transformer、attention、MLP、GNN

Transformer用注意力组织信息；MLP是多层感知机；GNN让图上的节点按连接交换信息。本项目正式上游有这些结构；风险层的树模型与它们是不同层次。主图不虚构新Transformer或GNN风险网络。

### TxPert、GAT、Exphormer、STRING

TxPert是现有扰动预测体系。GAT使用图注意力；Exphormer是另一种图变换结构；STRING提供分子相互作用网络资料。两条Source主结果共享研究与输出条件，称同体系跨预测器迁移。

### GEARS、scGPT

GEARS是图相关扰动预测方法；scGPT是单细胞Transformer预训练与微调方法。仓库有正式资产，也有早期借用表示或邻近预测的代理。名称相同不代表训练暴露、基因轴或能力相同。

### DecoderOnly、SAMS-VAE、VAE、generative

DecoderOnly是当前确定性预测机制；SAMS-VAE是另一种生成式变分模型。generative表示从合法输入与模型生成响应，不能以输入真实处理表达再重建的路径代替未知结果预测。

### counterfactual、generative_counterfactual、reconstruction、val_loss

counterfactual在此指指定扰动条件下的生成预测；开关启用对应推理路径。reconstruction是重建已给的表达；val_loss可能来自这种重建。训练损失下降与真正预测能力需要分别检查。

### TabPFN、V2、tabular foundation model

TabPFN是基于Transformer的表格基础模型，不是概率森林。本项目固定V2权重与checkpoint，复用既有特征，不重新预训练。一次替换结果只说明该版本和输入条件的表现。

### PerturbMap、RawCopy、RecipientMean

PerturbMap研究跨背景真实响应转换。RawCopy直接用合法来源历史；RecipientMean使用训练目标背景均值。均值是重要简单对照，用来判断映射是否只学到目标均值。

### ProjectedCopy、ScalarAffine、RidgeTransport、ShuffledPairTransport

ProjectedCopy只作同一低维投影；ScalarAffine再拟合标量尺度与均值调整；RidgeTransport学习低维线性映射；ShuffledPairTransport打乱训练配对身份后重做整个流程。正则选择仅用训练区重建误差。

### rank-8、SVD、regularization selection

rank-8指固定八维公共映射基底。SVD用于求正交基。有效秩不足时记录退化，不补出假维度。λ候选仅在训练内部比较，风险评价成绩不决定映射正则。

### residual、残差适配

残差是已有预测或风险目标还没解释掉的部分。已有残差方法保留，不能只换名称当成新算法。训练残差和上层模型同样要隔离评价答案。

### Risk Advisor、MORPH、PRESCRIBE

Risk Advisor研究现成黑盒的后置失败风险学习；MORPH有使用当前模型实际错误安排后续实验的步骤；PRESCRIBE联合研究模型与数据不确定性。它们使本项目的差异必须具体到公共实验复用、A/B→C与标签成本。

### epistemic、aleatoric、Bayesian

epistemic对应知识/模型方面的不确定性；aleatoric对应实验与数据生成中的变化；Bayesian指以概率模型处理未知量。不能把所有历史差异或细胞采样噪声都自动命名为其中一类。

### active learning、MMD

主动学习决定下一批获取哪些实验答案。MMD是比较两个样本分布的差异量；MORPH的误差监督涉及它。本项目当前主表使用效应RMSE，不把两种误差直接混合训练。

## 5. 特征字段逐项解释

### predicted_magnitude

预测效应的均方根幅度，sqrt(mean(ŷ²))。它是Source六项预测特征之一，也作无历史起点。

### prediction_abs_mean

预测效应各基因绝对值的平均mean(abs(ŷ))。它不同于均方根，但二者都只读取预测。

### prediction_signed_mean

预测效应保留正负号的平均。正负变化可能抵消，所以不能拿它代替绝对幅度。

### prediction_std

预测效应在输出基因间的标准差。它描述一个向量的不同基因变化，不是多个实验重复的误差。

### prediction_abs_q95

abs(ŷ)的95%分位数，描述较大的预测变化。95%在此是向量分位，不是统计置信度。

### prediction_sparsity

预测中abs(ŷ)≤1e-8的基因比例。本版本使用固定阈值，旧相对阈值版本单独归档。

### prior_magnitude

公共参照µ的均方根幅度。它反映历史预计的生物变化大小，不来自当前查询真值。

### prediction_prior_rmse

当前预测与公共参照µ之间的RMSE距离，即D。注意它和预测对当前实验真值的真实误差不是同一个量。

### prediction_prior_cosine

预测与参照向量的余弦相似度，描述方向一致程度。近零向量无法稳定定义方向，按合同记缺失。

### prior_uncertainty

当前缓存中的历史分散度开方σ。需要进入R²时使用σ²，等于公式中的V。它不自动是参照均值标准误。

### log_history_support

历史支持量的log1p变换，降低数值跨度。当前值与细胞支持相关，不能按名称理解成独立实验条数。

### effective_sources

登记的有效权重来源数量，描述权重是否集中。应结合具体实现和实际独立记录数报告。

### history_conflict

登记的历史原始冲突统计。它和经学习、投影或映射后的分散度不是同一个字段。

### shared_risk、F0、F1、F2、P、PUBLIC

shared_risk是冻结共享读取器分数。P表示六项预测列；PUBLIC表示七项公共列。F0=P，F1=P+PUBLIC，F2再加入合法shared_risk。增加F2属于新增来源信息条件。

### native_prediction_abs_mean

Native61中的预测绝对均值；本次公平比较已从当前冻结预测重算，避免旧轴缓存的预测特征混入。

### native_control_baseline、native_control_dropout

分别为目标基因的控制表达基线和控制表达缺失/零比例。只来自允许的控制资料。

### native_control_plate_variance_proxy

控制表达的实验板变化代理量。与官方供体方差的统计对象不同，作为输入适配注明。

### native_state_0至native_state_5

六个背景状态编码字段，每条记录对应的状态置1。数字只是类别索引，不表示状态强弱或时间顺序。

### native_embedding_0至native_embedding_49

控制表达表示的50个数值坐标。它们是一个整体表示，某个坐标通常不能直接解释为某个基因或生物通路。

### native_training_similarity

到当前合法训练原型的最近表示距离。本轮有原self-prototype版本与排除同基因修复版本，不能混用两者结果。

### support_risk、simple_history_risk、true_error_rmse

support_risk是已有支持量评分；simple_history_risk是当前公共规则的原始分数；true_error_rmse是按当前输出合同从预测与评价效应计算的误差。前两项可作为分数，最后一项只作训练监督或评价。

## 6. 统计、训练隔离和研究结论

### RMSE、MSE、RMS、WMSE

MSE为各基因预测差的平方平均，RMSE再开方；RMS可以指一个向量的均方根或注册家族的RMS误差，须看对象。WMSE对基因或误差位置使用登记权重，不能依据结果临时改变权重。

### U20、Utility@20

固定选择ceil(0.2n)个最高风险任务。U20=(被选任务平均误差−总体均值)/(真实最高误差20%均值−总体均值)。1表示达到该集合的理想高误差选择，0表示均值无提升，负值表示选择误差比总体更低。n<20或分母不足时为NA。

### ceil、k、n

ceil是向上取整；n为合法评价任务数，k=ceil(0.2n)。n=212时k=43。不同分层各自取ceil后，与全量一次选43是不同选择程序。

### 严重错误、大误差、oracle、oracle top20%

当前大误差指队列里真实误差最高20%，是相对定义，没有另设医学阈值。oracle按真实误差选最差k项，只用于评价，不能进入实际风险评分。

### hit、found、recall、precision、miss rate

hit/found是命中真实大误差任务数；recall是命中数除以真实大误差集合大小；precision是命中数除以复核数；miss rate为漏检比例。当前两个集合都取43，precision与recall数值相同，22/43=51.16%。

### 剩余平均误差 / remaining mean error, retained

删除复核任务后保留下来预测的平均误差。7.07%是Public保留均值相对幅度复核保留均值的下降，不表示原模型输出整体提升7.07%。

### AURC、risk-coverage curve、coverage

按风险从低到高逐步保留预测，记录每个覆盖比例的平均误差，再对曲线求平均/面积。AURC越低越好。coverage可能指保留比例，也可能指区间覆盖或历史覆盖，必须按对象解释。

### Spearman、Pearson、ρ、correlate

Spearman比较排序关系，Pearson比较线性数值关系。风险与误差正相关说明高分通常更高误差。ρ用于相关系数；相关高不等于复核效用提高，也不证明因果机制。

### partial correlation、条件相关、残差相关

控制幅度等登记变量之后，检查剩余关联。它用于发现强起点以外的描述性信息，不能单独证明新算法、跨研究泛化或固定复核增益。

### CI、95% confidence interval

95%置信区间描述统计程序的抽样不确定性。差值区间包含0说明数据允许两个方向；结合点增量、实际门和成本作方法决定。它不是95%的概率说这个特定模型一定好，也不是未来单任务区间。

### bootstrap、paired、cluster bootstrap

bootstrap反复重采样估计统计量波动；paired让多个方法用同一批抽样；cluster按完整基因簇同步抽取各背景和预测器记录。本项目主要差值采用5000次，不把行、种子当独立实验。

### point estimate、bootstrap mean、macro、pooled

点估计来自实际队列；bootstrap mean是重采样统计量平均。macro先算各登记分层再等权汇总；pooled直接在合并记录上计算。不同方式可能出现相反关系，比较必须使用原登记规则。

### Fisher-z、meta-analysis、study

Fisher-z是相关系数的统计变换；meta-analysis汇总多研究效应并处理异质性。study是独立研究，多个背景、折或模型不自动形成多个研究。E153已有重复结构校正。

### 训练、开发、验证、评价 / TRAIN, DEV, VALIDATION, HOLDOUT, TEST

TRAIN用于拟合；DEV用于方法选择；VALIDATION要看它属于上游还是风险层；HOLDOUT是该次拟合留出的评价；TEST有永久封存与访问合同。文件名不自动决定其科学角色。

### SEEN、retrospective、confirmation

SEEN表示研究开发已看过这组结果，不等于上游训练必然见过其真值。retrospective是回顾分析。confirmation是配置冻结后按合同读取确认结果；新拆折不让已见数据变成全新外部确认。

### fold、GroupKFold、gene-disjoint、LOPO、LODO

fold是一份分区。GroupKFold把同基因记录整体拆开；gene-disjoint表示训练与评价基因不重叠；LOPO/LODO按原协议分别留出扰动或供体/研究，需核对当期定义，不能只看缩写。

### nested、inner、outer、cross-fitting

outer用于风险评价；inner在外层训练区内选参数或构造折外特征；nested意味着每一层都重新遵守排除。cross-fitting使每条训练输入来自没使用该条答案的下层模型。

### 泄漏 / leakage, exposure, isolation

泄漏是本应未知的评价信息影响训练、特征、CDF或选择。exposure描述上游是否拟合或选模用过当前任务。隔离包含整个依赖链，仅检查最后一层训练行不够。

### random pair、row holdout、column holdout、double unseen

把背景作行、扰动作列。random pair只缺某些组合；row holdout整个背景未见；column holdout整个扰动未见；double unseen两者同时未见。矩阵图是拆分示意，不是实验计数。

### cross-family、same-family、cross-study、cross-context

分别是跨模型体系、同体系、跨研究、跨背景。GAT和Exphormer在相同TxPert协议里的结果与SAMS/DecoderOnly异机制结果分开；同研究换背景不能叫新研究确认。

### 能力门 / competence, operational gate, noninferiority

能力门检查上游是否达到登记的基本预测可用要求。操作性通过与显著超过简单预测器是两个判断。SAMS通过当前门，旧六个scGPT/GEARS批次的失败记录另保留。

### 基线、强对照 / baseline, comparator, strong simple baseline

基线是比较起点。要同时看幅度、支持量、公共距离、预测特征学习器和同信息官方适配，才能说明新增信息和算法作用。选择弱对照不会增加真实方法价值。

### 消融、负对照、置乱 / ablation, negative control, shuffle, null

消融删一类信息；负对照保留规模却破坏应有对应关系。内容置乱改历史效应对应；配对置乱改背景映射锚点；标签置乱改Source错误对应。它们检验不同机制，不能互相代替。

### block shuffle、stratified、permutation

block shuffle整体移动同扰动的兼容标签块，保留同簇结构；stratified在研究、输出、背景等兼容层内置乱；permutation是置换。真实与置乱流程都重新训练及选阈值，不能偷用真实流程赢家。

### 信息增量、算法增量 / information, algorithm

信息比较只增加Public、Source或反馈之一，登记新增成本；算法比较固定输入、标签、任务和规则，只换学习器。Source HGB比无标签距离好不等于HGB算法创新。

### 反馈预算、准备成本 / budget, preparation cost

反馈预算按实际开放的基因簇和记录并集。此前542个开发任务用于选型等是准备成本；额外114个反馈基因不能被表述成整个研究只看过114个基因错误。

### 信息账本 / information budget ledger, union

账本分别记录生物真值、Source错误、C开发与反馈错误、CDF、选择、融合和模型调用。union按实际使用记录的并集去重，不只数最后训练器的行。

### 采用门 / adoption gate, threshold

采用门是事前约定的实际收益和风险要求，例如ΔU20≥0.005以及AURC/漏检/分层条件。0.005不是显著性水平。阈值只在开发侧确定，不能看评价队列换配置。

### NA、PASS、FAIL、ABSTAIN、COMPLETE

NA是指标不可计算；PASS/FAIL是某项登记门结果；ABSTAIN是该条件不输出相应保证；COMPLETE只是工程阶段结束。它们都不等于论文录用或每个科学主张成立。

### 正对照、技术分半 / positive control, split-half

正对照用预期应有生物信号的真实重复检查指标；技术分半把同实验细胞拆开，检查采样稳定性。技术分半不自动成为独立guide/plate或生物重复。

### 模拟增长、顺序回放 / growth, replay, prospective

模拟增长按固定哈希顺序逐批加入资料；回放先保存下一批分数，再揭示该批答案、更新并预测后续批。两者是回顾性模拟；prospective指真正面向后来到达的任务。

## 7. 数据、发表与复现

### McFaline、McFaline23

当前主效果与反馈比较的数据来源名称。本文主评价212任务/152基因簇，反馈池331/228，开发准备542/377；这些角色不互换。不同背景和处理条件按资产表登记。

### Replogle、GWPS、K562

Replogle是公共扰动研究来源；GWPS表示全基因组规模扰动筛选；K562是细胞系背景。完整GWPS是已在本机的公共资产，新增历史资格和实际覆盖仍按对齐检查计算。

### RPE1、HepG2、Jurkat、HCT116、HEK293T

这些是不同细胞系背景名称，不是不同预测器。HCT116/HEK293T用于本项目Orion或背景映射路线时，要记录是否同时换了研究、对照和输出合同。

### Nadig、Kaden、Norman、Adamson、Frangieh

公开遗传扰动研究或当前资产的来源名称。不同研究有不同背景、单/多基因扰动、基因轴和训练暴露；不因为都属遗传扰动就混池。

### Haber、Parekh、KaggleCrossCell、KaggleCrossPatient

5月原型和适配阶段的来源名称。Kaggle两个设置涉及跨细胞或跨病人化学扰动。本文只用它们说明历史阶段，当前主表不把这些适配跑通当成正式深模型确认。

### Cui、Santinha、Lara、McFarland、sciplex3、Tahoe

这些是早期公开数据或资产名称。Cui的细胞因子、Santinha的遗传扰动、McFarland/sciplex/Tahoe药物资料要按真实干预类型分开，旧表字段错误以更正审计为准。

### Orion、E258、Feng、Jiang24

Orion在本项目指另一预测与公共覆盖队列；E258/Feng用于已开放验证供体的可靠性诊断，其封存测试另守合同；Jiang24属于已有独立任务线。名称或存在checkpoint不自动授权测试真值访问。

### E90、E153、E168、E172、E181、E182、E189、E201、E205、E207

E编号是实验索引。数字和日期用来定位文件，不是算法版本。E182旧证书门与后来同研究Public回顾审计是不同分析；都保留原任务和端点。

### TCBB、CCF-B、中科院二区、JCR

TCBB是计算生物学与生物信息学期刊。CCF-B是计算机学会目录等级，中科院分区和JCR分区是另外的评价体系。本文首投选择以TCBB的CCF-B身份明确落地，学校分区按认可年份行政核对。

### Nature风格、scientific overview、schematic

这里指参考科学论文的对象表达、短标签、分面和计算关系，图是原创示意。视觉形式不代表达到某期刊录用水平，也不能代替真实实验数字。

### NeurIPS、Nature Biotechnology

NeurIPS是学术会议，本项目PRESCRIBE引用其正式论文；Nature Biotechnology是生物技术期刊，本项目引用其评价指标研究。名称用于定位文献，和当前投稿期刊及CCF等级分别说明。

### E195、E208

E195是Norman原生GEARS及不确定性资产；E208是Jiang24外部任务线。它们有各自训练暴露、输出轴、能力门和数据访问条件，不因为存在文件就自动成为全新确认。

### SourceHGB、comparison、content、experimental

SourceHGB就是Source HGB的紧凑写法；comparison表示比较；content表示历史响应的具体内容；experimental表示实验相关。这些词不单独增加一个算法。

### figures、five、fold-safe、minus、real

figures是图文件目录；five为五个；fold-safe表示该次计算遵守折间隔离；minus表示差值中的减法；real指对照中的真实对应版本。图里的real minus shuffled是同一任务真实分数的U20减置乱分数的U20。

### PDF

PDF是固定页面文档格式，本轮暂停生成论文PDF；提供的是Markdown文档和独立PNG/SVG图。

### novelty、contribution、claim、evidence

novelty是与已有工作的具体新差异；contribution是实际解决的问题；claim是文章主张；evidence是对应结果和范围。换学习器名字、基础恒等式、拟合数量本身不计为新贡献。

### 复现 / reproducibility, replication, checkpoint

计算复现是用相同数据代码重算；复制性检验是在另一个数据或实验条件重现规律。checkpoint是模型参数文件，只凭文件存在不能判断其数据 exposure 合格。

### Git、commit、hash、SHA256、manifest、run_id

Git记录版本；commit标识一次提交；hash/SHA256标识文件内容；manifest列来源和输出；run_id标识一次运行。它们用于追溯和恢复，不是科学增量或独立样本。

### CSV、Parquet、JSON、MD、SVG、PNG

这些是结果/文档文件格式。CSV为表格文本，Parquet为列式表格，JSON为结构化配置，MD为Markdown文档，SVG为可编辑矢量图，PNG为位图。图单独导出，主文通过编号引用。

### CPU、GPU、CPU-core-hours、GPU-hours

CPU处理数据和树模型，GPU用于部分神经模型。资源时数按实际使用累积，不由新合同重置。此次Native诊断为36次CPU小拟合，新增GPU训练和数据下载为0。

## 逐步算一个U20结果

假设100个任务，复核20项；总体平均误差为0.04，真正最高误差20项均值为0.10，某方法选出的20项均值为0.08。则U20=(0.08−0.04)/(0.10−0.04)=0.667。这里的数字只说明指标计算，不是本项目新结果。

当前真实队列212项、复核43项，PublicRule命中真实最差43项中的22项，因此命中率为22/43=51.16%。剩余误差下降比例采用(幅度方案剩余均值−Public方案剩余均值)/幅度方案剩余均值，不拿U20代替它。

## 图上常见英语与完整标签

**New prediction**：新预测结果；由冻结预测器产生，尚没有当前任务真实答案。

**Reference-aware risk**：利用公共参照的风险判断，主要计算预测与历史的距离及历史变化。

**Prioritise review**：按风险安排复核次序，固定资源下先选高风险任务。

**Perturbation + context**：扰动和任务背景共同确定预测任务。

**Frozen predictor**：参数和输出合同已经固定的预测器。

**Predicted effect**：预测的基因效应向量，不是测得真值。

**Outcome not yet observed**：当前任务的真实实验结果尚未获得或按协议保持未知。

**Public historical reference**：来自允许历史真实响应的公共参照。

**Public perturbation experiments**：可以用于当前查询的公共扰动实验。

**Matched histories across experiments**：按扰动和兼容条件匹配的不同实验历史。

**Reference / Prediction / Genes**：分别为公共参照、当前预测、输出基因位置。

**Support · conflict · history variation**：资料支持量、历史冲突和历史效应变化三个不同因素。

**Predictions + errors**：旧冻结模型的预测，以及这些预测在合法留出任务上的真实错误。

**Shared risk learner**：由Source错误监督训练的风险学习器。

**Optional transfer / Source conditional**：来源错误经验的可选迁移；只在登记兼容范围启用。

**Observed C errors / Target feedback candidate**：已经获得的C真实错误；用于训练待验收的目标候选。

**Optional adaptation for later predictions**：利用已获得反馈更新候选，服务之后的预测任务。

**Risk ranking / High → low risk**：风险排序，方向从高风险到低风险。

**Review top 20%**：选出最高风险ceil(0.2n)项；不是先看误差再选。

**Solid / Dashed**：实线表示公共主干，虚线表示可选学习输入。

**Current McFaline default: PublicRule**：当前McFaline完整配置选中PublicRule。

**Parallel family certificate**：独立并行的注册预测家族误差证书。

**Registered family spread → error lower bound**：事前注册家族的预测离散程度，给出家族误差下界。

**Separate from ranking**：证书和经验排序为两个不同研究对象。

**Does disagreement survive shift?**：研究问题：变化的留出设置下，模型分歧与误差的关系是否仍保持？

**Does the score beat magnitude?**：研究问题：当前风险分是否超过预测幅度这个强起点？

**Does better correlation improve review?**：研究问题：相关改善是否对应固定复核资源下的实际收益？

**What can be reused for a new model?**：研究问题：新预测器能复用哪些真实实验与其他模型经验？

**Random pair / Unseen perturbation / Unseen context / Double unseen**：分别为随机组合留出、整扰动留出、整背景留出、两者同时留出。

**Range across support budgets**：不同支持预算的结果范围，和置信区间分开。

**Old score / Magnitude / Partial ρ | magnitude**：旧固定分数、预测幅度、控制幅度后的条件相关。

**Disagreement is setting-dependent**：模型分歧的解释需要结合具体留出设置。

**Magnitude becomes the anchor**：幅度成为比较与设计起点；这里没有独立的新算法名为Anchor。

**Correlation and review differ**：相关关系和实际复核收益是不同指标。

**After reviewing PertEMA / Own errors → post-hoc learner**：核对PertEMA后明确：当前模型自身错误的后置学习已有近邻。

**Public experiments + other-model errors / Test cross-predictor information**：检验公共实验和其他模型错误能否帮助一个新预测器。

**Same-family transfer / DEV / SEEN**：同体系跨预测器结果；属于开发或已经看过的评价。

**Public rank / Source HGB / Selected gate**：公共秩通道、来源监督HGB、开发侧选定的切换候选。

**Context-macro U20 / three-seed mean**：按背景等权汇总U20，再对三个登记种子取平均。

**Feedback gene budget (%)**：允许使用的反馈基因簇占登记反馈池的比例，同时记录实际任务行。

**Native61 adaptation / Native61 + Public**：固定原生控制特征适配，以及同学习器增加公共特征的版本。

**No feedback / fixed first seed**：没有新增风险反馈的规则；或按事前固定的主种子展示。

**True high-error tasks discovered / reviewed tasks**：选中并命中真实最差集合的任务数，以及方法实际复核数量。

**Higher is better / lower is better**：分别表示指标越高越好或越低越好，U20与AURC方向不同。

**Source versus the strong prediction baseline / Public reference versus support**：来源监督与强幅度对照；公共参照与支持量对照。

## 错误CDF的一个具体计算

允许训练错误为[1,3,3,9]时，中间秩公式为(严格小于该值的数量+小于等于该值的数量)/(2n)。得到标签[0.125,0.5,0.5,0.875]。两个3对应相同标签；9的标签不是错误概率。这个例子只解释代码约定，不是新实验。

## 图例中补充短词

Random expectation表示随机选择的期望。当前43项复核的期望命中数为43²/212=8.72，图中的虚线不是一次实际随机试验结果。zero为零，violations为违反次数；zero lower-bound violations指登记下界审计中没有违反，和证明经验排序有效不同。

lower-bound/upper-bound为下界/上界，registered-family为注册家族，support-budget为支持预算。pathway表示图里的计算路径；learnt与learned都表示已学习的。each表示每一个，since表示自某时起；July为7月，Sept.为9月。

## 英语连接词与图例短词

图中的the/a/an表示所指对象；does/is/can构成“是否、是、能否”的句式；for是“用于”，with是“带有”，without是“没有”，from是“来自”，to是“到”，of是“属于/的”，and是“以及”，but是“但”，when是“在……条件下”，within是“在范围内”，across是“跨越”，versus/vs是“与……比较”，after/before是“之后/之前”。这些连接词不单独定义新的方法。

new/current/old/past/later分别是新、当前、旧、过去、后续；available/unavailable表示可用/不可用；true/observed/predicted分别为真实定义、已观察、预测；selected/registered/fixed分别为已选定、已登记、固定。数字后的tasks、genes、clusters、seeds分别指任务、基因、簇和种子，不能相互替换。
